<template>

</template>

<script>
export default {
   mounted(){

   },
   created(){

   },
   comments:{

   },
   data(){
    return{
      base_url: this.$store.state.image_base_link,
    }
   },
   methods:{

   },
   computed:{

   }

}
</script>